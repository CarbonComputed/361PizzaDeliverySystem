package pds.ui;

import javax.swing.JPanel;

public class ConfigMenuView extends JPanel{

}
