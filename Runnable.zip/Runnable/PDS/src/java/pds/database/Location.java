/**
 * 
 */
package pds.database;

import java.io.Serializable;

/**
 * @author Goombas
 *
 */
public class Location implements Serializable{
	
	
	private String location;
	private int distance;
	
	public Location(String location, int distance){

		this.location = location;
		this.distance = distance;
	}



	public String getLocation() {
		return location;
	}

	public int getDistance() {
		return distance;
	}
	
	
	
}
